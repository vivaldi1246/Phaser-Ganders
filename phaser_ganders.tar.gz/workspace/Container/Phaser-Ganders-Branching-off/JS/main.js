var game = new Phaser.Game(window.innerWidth * window.devicePixelRatio, window.innerHeight * window.devicePixelRatio, Phaser.CANVAS, 'gameCanvas', {preload: preload, create: create, update: update});

function preload(){
    game.load.image('background', 'assets/sky.jpg');
    game.load.image('star', 'assets/star.png');
    game.load.image('platforms', 'assets/platform.png');
    game.load.image('button', 'assets/button.png');
}

var colors = ['#FFFFFF', '#F06E62', '#7763D9', '#6EF0C4', '#CD26D9', '#F0D462', '#06F0AB'];
//var randomIndex = Math.floor(Math.random() * colors.length)
//var colorRandom = colors[randomIndex];

function create(){
    game.physics.startSystem(Phaser.Physics.ARCADE);
    this.game.stage.backgroundColor = '#697e96';
    game.backgroundSprite = this.game.add.tileSprite(0, this.game.height - this.game.cache.getImage('background').height, this.game.width, this.game.cache.getImage('background').height, 'background');
    this.game.scale.pageAlignHorizontally = true;
    this.game.scale.pageAlignVertically = true;
    this.game.scale.refresh();
    var starSprite = this.game.add.sprite(game.world.centerX, game.world.centerY - 200, 'star');
    starSprite.anchor.setTo(0.5,0.5);
    starSprite.scale.setTo(0.5,0.5);
    var button = this.game.add.button(game.world.centerX, game.world.centerY, 'button', actionOnClick, this, 2, 1, 0);
    button.anchor.setTo(0.5, 0.5);
    button.onInputOver.add(over, this);
    button.onInputOut.add(out, this);
    button.onInputUp.add(up, this);
    game.displayText = game.add.text(game.world.centerX, game.world.centerY + 300, 'Starting Text');
    game.displayText.anchor.setTo(0.5, 0.5);
    //platforms = game.add.group();
    //platforms.enableBody = true;
    //var ground = platforms.create(0, game.world.height - 64, 'ground');
    
}
var colorRandom;
var randomIndex;
function update(){
    game.displayText.angle += 5;
    randomIndex = Math.floor(Math.random() * colors.length);
    colorRandom = colors[randomIndex];
}
function actionOnClick(){
	game.displayText.fill = colorRandom;
}

function up(){
	game.displayText.setText("Up.");
}
function out(){
	game.displayText.setText("Out.");
}
function over(){
	game.displayText.setText("Over.");
}